﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace RuzLaba
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void MenuItem_Click_Red(object sender, RoutedEventArgs e)
        {
            Alesha.Background = Brushes.Red;
        }

        private void MenuItem_Click_1(object sender, RoutedEventArgs e)
        {

        }

        private void MenuItem_Click_Yellow(object sender, RoutedEventArgs e)
        {
            Alesha.Background = Brushes.Yellow;
        }

        private void MenuItem_Click_Infa(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Разраб лучший во вселенной");
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Разраб лучший во вселенной");
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            Alesha.Background = Brushes.Red;
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            Alesha.Background = Brushes.Yellow;
        }

        private void Image_MouseMove(object sender, MouseEventArgs e)
        {
            Navel.Text = "Изменить цвет";
        }

        private void Image_MouseMove_1(object sender, MouseEventArgs e)
        {
            Navel.Text = "Разраб";
        }

        private void MenuItem_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Escape)
            {
                this.Close();
            }
        }
    }
}
